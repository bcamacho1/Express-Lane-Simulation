
public class ExpressLane extends Lane
{
	public ExpressLane() { } 
}
